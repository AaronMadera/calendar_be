# docker-database-image

Image dockerfile for mongo db server.